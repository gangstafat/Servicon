Streamline Icon Set - Free Pack
===============================

Designer: Webalys (https://www.iconfinder.com/webalys)
License: Free for commercial use (Include link to authors website)
